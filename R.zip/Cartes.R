#------------------------------------------------------------------------------#
# La librairie Pacman doit être installée avant toute chose                    #
#------------------------------------------------------------------------------#
library(pacman)
#------------------------------------------------------------------------------#
# Les packages suivants permettent de générer les cartes                       #
#------------------------------------------------------------------------------#
pacman::p_load(readxl,dplyr,tidyr,openxlsx,Benchmarking,ggplot2,rDEA,lubridate,
               AER,viridis,ggrepel,htmlwidgets,webshot,webshot2,mapview,magick) 
library(rnaturalearth)
library(rnaturalearthdata)
library(sf)
#------------------------------------------------------------------------------#
# Indiquer les sentiers où se trouvent le programme R "DEA_FUNCTIONS.R",       #
# ainsi que ceux des données et des résultats                                  #
#------------------------------------------------------------------------------#
R_path     <- "./1-R/"
Data_path  <- "./2-Data/"
Resultats_path <- "./3-Resultats/"
#------------------------------------------------------------------------------#
# Lectures de données et des scores d'efficience                               #
#------------------------------------------------------------------------------#
df.Principale <- read_excel(paste0(Data_path,"BD_Chercheur.xlsx"),
                            sheet = "BD principale") %>% 
  group_by(CD_POINT_SER) %>% 
  summarise(Taille=sum(NbVisites))

# Polygone du Québec
Canada <- ne_states(country = "Canada", returnclass = "sf")
Quebec <- Canada %>% filter(name == "Québec")
qc_regions <- st_read(paste0(Data_path,"regio_s.shp"))

Geo <- read_excel(paste0(Data_path,"BD_Chercheur_Points de service.xlsx"), 
                  sheet = "Données", range = "A1:E130")

Eff.CS <- read_excel(paste0(Resultats_path,"EfficacitéMensuelle.xlsx"), 
                     sheet = "3.CS", range = "A1:D131")
Eff.CS <- Eff.CS %>% 
  filter(!is.na(Nom))

Eff.MD <- read_excel(paste0(Resultats_path,"EfficacitéMensuelle.xlsx"), 
                     sheet = "3.MD", range = "A1:D131"
                     )
                     
Eff.MD <- Eff.MD %>% 
  filter(!is.na(Nom))

df.CS <- Eff.CS %>% 
  left_join(Geo,by="CD_POINT_SER") %>% 
  filter(!is.na(Latitude)) %>% 
  left_join(df.Principale,by="CD_POINT_SER")

df.MD <- Eff.MD %>% 
  left_join(Geo,by="CD_POINT_SER") %>% 
  filter(!is.na(Latitude)) %>% 
  left_join(df.Principale,by="CD_POINT_SER")

# Conversion des points en format sf
pts_MD <- df.MD %>%
  st_as_sf(coords = c("Longitude", "Latitude"), crs = 4326)

pts_CS <- df.CS %>%
  st_as_sf(coords = c("Longitude", "Latitude"), crs = 4326)

Canada <- ne_states(country = "Canada", returnclass = "sf")

qc_regions <- st_make_valid(qc_regions)
Quebec     <- st_make_valid(Quebec)

qc_regions_qc <- st_intersection(
  st_transform(Quebec, 4326)
)

data = qc_regions_qc

qc_regions <- st_read(paste0(Data_path,"regio_s.shp"))

p_MD <- ggplot() +
  geom_sf(
    data = qc_regions,
    fill = "white",
    colour = "black"
  ) +
  geom_sf(
    data = pts_MD,
    aes(
      size = Taille,
      colour = eff_vrs
    )
  ) +
  scale_colour_viridis_c(
    option = "plasma",
    direction = -1,
    name = "Efficacité"
  ) +
  labs(
    size = "Volume annuel"
  ) +
  theme(
    legend.title = element_text(size = 8),
    legend.text  = element_text(size = 6),
    legend.key.height = unit(0.3, "cm"),
    legend.key.width  = unit(0.3, "cm"),
    legend.box = "vertical",
    legend.position = c(0.25, 0.75),
    legend.background = element_rect(
      fill = "white",
      colour = "grey80"
    )
  ) +
  guides(
    size = guide_legend(
      order = 1,
      keyheight = unit(0.3, "cm"),
      keywidth  = unit(0.3, "cm")
    ),
    colour = guide_colourbar(
      order = 2,
      direction = "horizontal",
      barwidth = unit(4, "cm"),
      barheight = unit(0.3, "cm")
    )
  )+
  coord_sf(
    ylim = c(44, 55),
    #xlim = c(-77,-63),
    expand = FALSE
  )

p_MD

ggsave(paste0(Resultats_path,"Carte_MD.pdf"),
  p_MD,
  width = 14,
  height = 8
)

p_CS <- ggplot() +
  geom_sf(
    data = qc_regions,
    fill = "white",
    colour = "black"
  ) +
  geom_sf(
    data = pts_CS,
    aes(
      size = Taille,
      colour = eff_vrs
    )
  ) +
  scale_colour_viridis_c(
    option = "plasma",
    direction = -1,
    name = "Efficacité"
  ) +
  labs(
    size = "Volume annuel"
  ) +
  theme(
    legend.title = element_text(size = 8),
    legend.text  = element_text(size = 6),
    legend.key.height = unit(0.3, "cm"),
    legend.key.width  = unit(0.3, "cm"),
    legend.box = "vertical",
    legend.position = c(0.25, 0.75),
    legend.background = element_rect(
      fill = "white",
      colour = "grey80"
    )
  ) +
  guides(
    size = guide_legend(
      order = 1,
      keyheight = unit(0.3, "cm"),
      keywidth  = unit(0.3, "cm")
    ),
    colour = guide_colourbar(
      order = 2,
      direction = "horizontal",
      barwidth = unit(4, "cm"),
      barheight = unit(0.3, "cm")
    )
  )+
  coord_sf(
    ylim = c(44, 56),
    #xlim = c(-77,-63),
    expand = FALSE
  )

p_CS

ggsave(paste0(Resultats_path,"Carte_CS.pdf"),
       p_CS,
       width = 14,
       height = 8
)

ggsave(paste0(Resultats_path,"Carte_CS.pdf"),
  p_CS,
  width = 12.5,
  height = 8
)

