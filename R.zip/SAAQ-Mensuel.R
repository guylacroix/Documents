#------------------------------------------------------------------------------#
# La librairie Pacman doit être installée avant toute chose                    #
#------------------------------------------------------------------------------#
library(pacman)
#------------------------------------------------------------------------------#
# Les packages suivants permettent de traiter les données                      #
#------------------------------------------------------------------------------#z
pacman::p_load(readxl,dplyr,tidyr,openxlsx,Benchmarking,ggplot2,rDEA,lubridate,
               AER)
#------------------------------------------------------------------------------#
Data_path  <- "./1-Data/"
Resultats_path <- "./2-Resultats/"
#------------------------------------------------------------------------------#
# Banque de données principale
df.Principale <- read_excel(paste0(Data_path,"BD_Chercheur.xlsx"),
                            sheet = "BD principale"
                            )
# Banque de données sur les raisons de visites
df.Raisons    <- read_excel(paste0(Data_path,"BD_Chercheur.xlsx"),
                            sheet = "BD sec. - Raison des visites"
                            )
# Fichier Excel pour calculer l'âge des clients - Définition groupes d'âges
df.Secondaire <- read_excel(paste0(Data_path,"BD_Chercheur.xlsx"),
                            sheet = "BD secondaire - Groupes d'âge") %>%
  filter(GroupeAge != "N.D.") %>% 
  mutate(AgeMoy = case_when(
    GroupeAge == "16 ans et moins" ~ 16,
    GroupeAge == "17 à 20 ans" ~ (17+20)/2,
    GroupeAge == "21 à 25 ans" ~ (21+25)/2,
    GroupeAge == "26 à 30 ans" ~ (26+30)/2,
    GroupeAge == "31 à 35 ans" ~ (31+35)/2,
    GroupeAge == "36 à 40 ans" ~ (36+40)/2,
    GroupeAge == "41 à 45 ans" ~ (41+54)/2,
    GroupeAge == "46 à 50 ans" ~ (46+50)/2,
    GroupeAge == "51 à 55 ans" ~ (51+55)/2,
    GroupeAge == "56 à 60 ans" ~ (56+60)/2,
    GroupeAge == "61 à 65 ans" ~ (61+65)/2,
    GroupeAge == "66 à 70 ans" ~ (66+70)/2,
    GroupeAge == "71 à 80 ans" ~ (71+80)/2,
    GroupeAge == "81 à 90 ans" ~ (81+90)/2,
    GroupeAge == "91 ans et plus" ~ 91)
  ) %>% 
  group_by(Annee,Mois,CD_POINT_SER) %>% 
  summarise(
    AgePond = weighted.mean(AgeMoy,NbVisites,na.rm = TRUE),
    .groups = "drop"
  )
# Fusion des deux premiers fichiers 
df.Total <- df.Principale %>% 
  inner_join(df.Raisons, by = c("CD_POINT_SER","Annee","Mois")) %>% 
  rename_with(~ sub("\\.y$", "", .x), ends_with(".y")) %>% 
  select(-ends_with(".x"))

Geo <- read_excel(paste0(Data_path,"BD_Chercheur_Points de service.xlsx"), 
                  sheet = "Données", range = "A1:E130")

df.Final <- df.Total %>% 
  inner_join(df.Secondaire, by = c("CD_POINT_SER","Annee","Mois")) %>% 
  filter(!is.na(AgePond)) %>% 
  left_join(Geo, by="CD_POINT_SER") %>% 
  select(-Nom_PS.y) %>% 
  rename(Nom_PS = Nom_PS.x) %>% 
  mutate(
      C0 = as.integer(Catégorie == "Très petit"),
      C1 = as.integer(Catégorie == "Petit"),
      C2 = as.integer(Catégorie == "Moyen"),
      C3 = as.integer(Catégorie == "Grand"),
      C4 = as.integer(Catégorie == "Très grand")
    )
saveRDS(df.Final, paste0(Data_path,"df.Final.Mensuel.rds"))   
#------------------------------------------------------------------------------#
# SCENARIO 3 - DONNEES CENTRES DE SERVICES                                     #
#------------------------------------------------------------------------------#
E1 <- c("Acquisition commerçant")
E2 <- c("Délivrance permis")
E3 <- c("Pratique promenade","Pratique moto","Pratique lourd")
E4 <- c("REC")
E5 <- c("Éval théorique")
E6 <- c("RAMQ","Création dossier SAAQ","Modification au dossier",
        "Impression relevé global","Changement d'adresse",
        "Ligne verte autre") 
E7 <- c("IRP","Remplacement plaque","Annul Immat","Immatriculation temporaire")
E8 <- c("Renouvellement Permis 8 ans","Médical/Sanction","Remplacement permis",
        "Annul Permis","Permis TRPA","Prise_RDV_Exam","Test visuel",
        "Dossier conduite")
E9 <- c("Remisage, déremisage","Rancart","Remisage",
        "Déremisage")
E10 <- c("Renouv Immat","Renouv Permis")
E11 <- c("Transfert")

df.3.CS <- readRDS(paste0(Data_path,"df.Final.Mensuel.rds")) %>% 
  filter(Canal == "Centre service SAAQ", 
         Annee == 2025) %>% 
  group_by(Annee,CD_POINT_SER) %>%
  mutate(N=n_distinct(Mois)) %>% 
  filter(N>=4) %>% 
  ungroup() %>% 
  group_by(Annee,Mois,CD_POINT_SER) %>% 
  summarise(
    Canal = Canal[1],
    Nom   = Nom_PS[1],
    C0    = C0[1],
    C1    = C1[1],
    C2    = C2[1],
    C3    = C3[1],
    C4    = C4[1],
    Y1 = sum((RaisonVisite %in% E1)*NbVisites, na.rm = TRUE), 
    Y2 = sum((RaisonVisite %in% E2)*NbVisites, na.rm = TRUE), 
    Y3 = sum((RaisonVisite %in% E3)*NbVisites, na.rm = TRUE), 
    Y4 = sum((RaisonVisite %in% E4)*NbVisites, na.rm = TRUE), 
    Y5 = sum((RaisonVisite %in% E5)*NbVisites, na.rm = TRUE), 
    Y6 = sum((RaisonVisite %in% E6)*NbVisites, na.rm = TRUE), 
    Y7 = sum((RaisonVisite %in% E7)*NbVisites, na.rm = TRUE), 
    Y8 = sum((RaisonVisite %in% E8)*NbVisites, na.rm = TRUE), 
    Y9 = sum((RaisonVisite %in% E9)*NbVisites, na.rm = TRUE), 
    Y10 = sum((RaisonVisite %in% E10)*NbVisites, na.rm = TRUE),
    Y11 = sum((RaisonVisite %in% E11)*NbVisites, na.rm = TRUE),
    NbASCMoy = mean(
      if_else(
        Canal == "Centre service SAAQ" & !is.na(Prop_LV_ASC),
        NbASC_Moy * Prop_LV_ASC,
        NbASC_Moy
      ),
      na.rm = TRUE
    ),
    NB_ASC_MOY = mean(NB_ASC),
    ExpMoyASC = mean(
      coalesce(ExpMoy_ASC, 0)
    ),
    ExpMoyComptoir = mean(ExpMoy_Comptoir, na.rm = TRUE),
    NbMoyEval = mean(
      coalesce(NB_Eval, 0) 
    ),
    ExpMoyEval = mean(
      coalesce(ExpMoy_Eval, 0) 
    ),
    NbAutre = mean(NB_Autre, na.rm = TRUE),
    ExpMoyAutre = mean(ExpMoy_Autre, na.rm = TRUE),
    # VARIABLES D'ENVIRONNEMENT
    AgeMoy = mean(AgePond, na.rm = TRUE),
    HeuresDebordement = as.numeric(sum(heures_Debordement, na.rm = TRUE)>0),
    HeuresSoir = as.numeric(sum(heures_soir, na.rm = TRUE)>0),
    HeuresWE = as.numeric(sum(heures_weekend, na.rm = TRUE)>0),
    NbJoursFeries = as.numeric(sum(NbJourFerieOuvert, na.rm = TRUE)>0),
    NbJourImma = as.numeric(sum(Nb_Jrs_Ouvres_Immat, na.rm = TRUE)>0),
    PropImm = as.numeric(sum(NbVisites_REC)/sum(NbVisites)),
    Temps = mean(minute(MoyTempsAtt)*60 + second(MoyTempsAtt),na.rm=TRUE),
    PropEnt = as.numeric(sum(NbVisites_Entreprises)/sum(NbVisites)),
    .groups = "drop"
  )
#------------------------------------------------------------------------------#
# SCENARIO 3 - DONNEES MANDATAIRES                                             #
#------------------------------------------------------------------------------#
E1 <- c("Acquisition commerçant")
E2 <- c("Délivrance permis")
E3 <- c("RAMQ","Création dossier SAAQ","Modification au dossier",
        "Impression relevé global","Changement d'adresse",
        "Ligne verte autre")
E4 <- c("IRP","Remplacement plaque","Annul Immat","Immatriculation temporaire")
E5 <- c("Renouvellement Permis 8 ans","Médical/Sanction","Remplacement permis",
        "Annul Permis","Permis TRPA","Prise_RDV_Exam","Test visuel",
        "Dossier conduite")
E6 <- c("Remisage, déremisage","Rancart","Remisage",
        "Déremisage")
E7 <- c("Renouv Immat","Renouv Permis")
E8 <- c("Transfert")

df.3.MD <- readRDS(paste0(Data_path,"df.Final.Mensuel.rds")) %>% 
  filter(Canal != "Centre service SAAQ", 
         Annee == 2025) %>% 
  group_by(Annee,CD_POINT_SER) %>%
  mutate(N=n_distinct(Mois)) %>% 
  filter(N>=4) %>% 
  ungroup() %>% 
  group_by(Annee,Mois,CD_POINT_SER) %>% 
  summarise(
    Canal = Canal[1],
    Nom   = Nom_PS[1],
    Y1 = sum((RaisonVisite %in% E1)*NbVisites, na.rm = TRUE),
    Y2 = sum((RaisonVisite %in% E2)*NbVisites, na.rm = TRUE),
    Y3 = sum((RaisonVisite %in% E3)*NbVisites, na.rm = TRUE),
    Y4 = sum((RaisonVisite %in% E4)*NbVisites, na.rm = TRUE),
    Y5 = sum((RaisonVisite %in% E5)*NbVisites, na.rm = TRUE),
    Y6 = sum((RaisonVisite %in% E6)*NbVisites, na.rm = TRUE),
    Y7 = sum((RaisonVisite %in% E7)*NbVisites, na.rm = TRUE),
    Y8 = sum((RaisonVisite %in% E8)*NbVisites, na.rm = TRUE),
    C0    = C0[1],
    C1    = C1[1],
    C2    = C2[1],
    C3    = C3[1],
    C4    = C4[1],
    NbASCMoy = mean(NbASC_Moy, na.rm = TRUE),    
    ExpMoyASC = mean(ExpMoy_Comptoir, na.rm = TRUE),
    # VARIABLES D'ENVIRONNEMENT
    AgeMoy = mean(AgePond, na.rm = TRUE),
    HeuresDebordement = as.numeric(sum(heures_Debordement, na.rm = TRUE)>0),
    HeuresSoir = as.numeric(sum(heures_soir, na.rm = TRUE)>0),
    HeuresWE = as.numeric(sum(heures_weekend, na.rm = TRUE)>0),
    NbJoursFeries = as.numeric(sum(NbJourFerieOuvert, na.rm = TRUE)>0),
    NbJourImma = as.numeric(sum(Nb_Jrs_Ouvres_Immat, na.rm = TRUE)>0),
    PropImm = as.numeric(sum(NbVisites_REC)/sum(NbVisites)),
    Temps = mean(minute(MoyTempsAtt)*60 + second(MoyTempsAtt),na.rm=TRUE),
    PropEnt = as.numeric(sum(NbVisites_Entreprises)/sum(NbVisites)),
    .groups = "drop"
  ) 
#------------------------------------------------------------------------------#
# SCENARIO 3 - DONNÉES MANDATAIRES ET CENTRES DE SERVICES                      #
#------------------------------------------------------------------------------#
E1 <- c("Acquisition commerçant")
E2 <- c("Délivrance permis")
E3 <- c("RAMQ","Création dossier SAAQ","Modification au dossier",
        "Impression relevé global","Changement d'adresse",
        "Ligne verte autre")
E4 <- c("IRP","Remplacement plaque","Annul Immat","Immatriculation temporaire")
E5 <- c("Renouvellement Permis 8 ans","Médical/Sanction","Remplacement permis",
        "Annul Permis","Permis TRPA","Prise_RDV_Exam","Test visuel",
        "Dossier conduite")
E6 <- c("Remisage, déremisage","Rancart","Remisage",
        "Déremisage")
E7 <- c("Renouv Immat","Renouv Permis")
E8 <- c("Transfert")

df.3.CS.MD <- readRDS(paste0(Data_path,"df.Final.Mensuel.rds")) %>% 
  filter(Annee == 2025) %>% 
  group_by(Annee,CD_POINT_SER) %>%
  mutate(N=n_distinct(Mois)) %>% 
  filter(N>=4) %>% 
  ungroup() %>% 
  group_by(Annee,Mois,CD_POINT_SER) %>% 
  summarise(
    Canal = Canal[1],
    Nom   = Nom_PS[1],
    n_mois = n_distinct(Mois),
    Y1 = sum((RaisonVisite %in% E1)*NbVisites, na.rm = TRUE),
    Y2 = sum((RaisonVisite %in% E2)*NbVisites, na.rm = TRUE),
    Y3 = sum((RaisonVisite %in% E3)*NbVisites, na.rm = TRUE), 
    Y4 = sum((RaisonVisite %in% E4)*NbVisites, na.rm = TRUE), 
    Y5 = sum((RaisonVisite %in% E5)*NbVisites, na.rm = TRUE), 
    Y6 = sum((RaisonVisite %in% E6)*NbVisites, na.rm = TRUE), 
    Y7 = sum((RaisonVisite %in% E7)*NbVisites, na.rm = TRUE), 
    Y8 = sum((RaisonVisite %in% E8)*NbVisites, na.rm = TRUE), 
    C0    = C0[1],
    C1    = C1[1],
    C2    = C2[1],
    C3    = C3[1],
    C4    = C4[1],
    NbASCMoy = mean(
      if_else(
        Canal == "Centre service SAAQ" & !is.na(Prop_LV_ASC),
        NbASC_Moy * Prop_LV_ASC,
        NbASC_Moy
      ),
      na.rm = TRUE
    ),
    ExpMoyASC = mean(ExpMoy_Comptoir, na.rm = TRUE),
    # VARIABLES D'ENVIRONNEMENT
    AgeMoy = mean(AgePond, na.rm = TRUE),
    HeuresDebordement = as.numeric(sum(heures_Debordement, na.rm = TRUE)>0),
    HeuresSoir = as.numeric(sum(heures_soir, na.rm = TRUE)>0),
    HeuresWE = as.numeric(sum(heures_weekend, na.rm = TRUE)>0),
    NbJoursFeries = as.numeric(sum(NbJourFerieOuvert, na.rm = TRUE)>0),
    NbJourImma = as.numeric(sum(Nb_Jrs_Ouvres_Immat, na.rm = TRUE)>0),
    PropImm = as.numeric(sum(NbVisites_REC)/sum(NbVisites)),
    PropEnt = as.numeric(sum(NbVisites_Entreprises)/sum(NbVisites)),
    Temps = mean(minute(MoyTempsAtt)*60 + second(MoyTempsAtt),na.rm=TRUE),
    .groups = "drop"
  )         
#------------------------------------------------------------------------------#
# COMPILATION DES FONCTIONS D'OPTIMISATION                                           #
#------------------------------------------------------------------------------#
source("./DEA_FUNCTIONS.R") # NE PAS MODIFIER
#------------------------------------------------------------------------------#
# CS - TROISIEME SCENARIO                                                      #
#------------------------------------------------------------------------------#
inputs <- c("NB_ASC_MOY","ExpMoyASC","ExpMoyComptoir","NbMoyEval","ExpMoyEval",
            "NbAutre","ExpMoyAutre")

z_var <- c("HeuresDebordement","PropImm","PropEnt","AgeMoy","C0","C1","C2","C3")

outputs <- paste0("Y", 1:11)
#------------------------------------------------------------------------------#
# Nomenclature:                                                                #
# eff.3.CS -> efficience brute, centres de services                            #
# eff -> Efficience                                                            #
#    .3 -> 3e scénario                                                         #
#      .CS -> Centres de services                                              #
# eff.3.CS_Z -> efficience, nette des facteurs d'environnement (Variables Z)   #
#------------------------------------------------------------------------------#
df.3.CS.CLEAN <- df.3.CS %>% # On enlève les valeurs manquantes
  filter(!if_any(all_of(c(inputs, outputs, z_var)), is.na)) %>%
  select(Mois, CD_POINT_SER, everything()) %>% 
  mutate(AgeMoy=AgeMoy/100)

eff.3.CS <- dea_crs_vrs(df.3.CS.CLEAN, inputs, outputs, ORIENTATION = "in") %>%
  mutate(
    CD_POINT_SER = df.3.CS.CLEAN$CD_POINT_SER,
    Mois = df.3.CS.CLEAN$Mois
  ) %>% 
  left_join(df.3.CS.CLEAN, by = c("Mois","CD_POINT_SER"))

eff.3.CS.Z <- dea_crs_vrs_Z(df.3.CS.CLEAN, inputs, outputs, z_var,ORIENTATION = "in") %>% 
      mutate(Mois=df.3.CS.CLEAN$Mois) %>% 
      left_join(df.3.CS.CLEAN, by = c("Mois","CD_POINT_SER"))
#------------------------------------------------------------------------------#
# Calcul du rang des CS selon eff.3.CS et eff.3.CS_Z :                         #
# Pas présenté dans le rapport                                                 #
#------------------------------------------------------------------------------#
df <- eff.3.CS.Z %>%
  mutate(
    rk_vrs1 = dense_rank(desc(eff_vrs)),
    rk_vrs2 = dense_rank(desc(eff_vrs_Z)),
    diff_rk = rk_vrs1 - rk_vrs2 # Différence de rang
  ) %>%
  select(Mois,Nom,CD_POINT_SER,eff_vrs,eff_vrs_Z,rk_vrs1,rk_vrs2,diff_rk,Temps) %>% 
  ungroup()
# Corrélation entre les rangs selon eff.1.CS et eff.1.CS_Z
cor(df$rk_vrs1, df$rk_vrs2, method = "spearman", use = "complete.obs")
cor(df$rk_vrs1, df$rk_vrs2, method = "kendall",  use = "complete.obs")
#------------------------------------------------------------------------------#
# Rang des CS, des plus efficaces aux moins efficaces                          #
#------------------------------------------------------------------------------#
rank_firms <- eff.3.CS.Z %>%
  group_by(Annee,CD_POINT_SER) %>%
  summarise(mean_eff = mean(eff_vrs, na.rm = TRUE), .groups = "drop") %>%
  arrange(desc(mean_eff)) %>% 
  ungroup() %>% 
  left_join(df.3.CS.CLEAN,by=c("Annee","CD_POINT_SER")) %>% 
  group_by(CD_POINT_SER) %>% 
  slice(1) %>% 
  select(-Annee,-Mois) %>% 
  arrange(desc(mean_eff))

df <- eff.3.CS.Z %>%
  group_by(CD_POINT_SER) %>% 
  summarise(eff_brut=mean(eff_vrs),
            eff_net=mean(eff_vrs_Z),
            Nom=Nom[1]
  ) %>% 
  ungroup() %>% 
  mutate(
    rk_vrs1 = dense_rank(desc(eff_brut)),
    rk_vrs2 = dense_rank(desc(eff_net)),
    diff_rk = rk_vrs1 - rk_vrs2
  ) %>%
  select(Nom,CD_POINT_SER,eff_brut,eff_net,rk_vrs1,rk_vrs2,diff_rk) %>% 
  ungroup()
#------------------------------------------------------------------------------#
# Régression Tobit des scores d'efficacité bruts sur les variables             #
# d'environnment.  Courant, mais pas recommandé                                #                #
#------------------------------------------------------------------------------#
fit_tobit <- tobit(
  eff_vrs ~ AgeMoy+HeuresDebordement+PropImm+PropEnt+C0+C1+C2+C3,
  left  = 0,
  right = 1,
  data = eff.3.CS
) 
summary(fit_tobit)
#------------------------------------------------------------------------------#
# Récupération des paramètres de la régression non-linéaire de l'efficacité    #
# brute sur le variables d'environnement selon la fonction dea_crs_vrs_Z       #
# ci-dessus. Méthode recommandée et mentionnée dans le rapport.                #
#------------------------------------------------------------------------------#
reg.3.CS <- attr(eff.3.CS.Z, "rdea_regression")

est <- reg.3.CS$beta_hat_hat
ci  <- reg.3.CS$beta_ci

se <- (ci[, 2] - ci[, 1]) / (2 * 1.96)
tval <- est / se
pval <- 2 * (1 - pnorm(abs(tval)))

coef_table <- data.frame(
  variable   = names(est),
  estimate   = as.numeric(est),
  std_error  = as.numeric(se),
  t_value    = as.numeric(tval),
  p_value    = as.numeric(pval)
  #ci_low     = ci[, 1],
  #ci_high    = ci[, 2]
)

coef_table.3.CS <- coef_table %>%
  mutate(
    stars = case_when(
      p_value < 0.01 ~ "***",
      p_value < 0.05 ~ "**",
      p_value < 0.10 ~ "*",
      TRUE ~ ""
    )
  )
coef_table.3.CS
#------------------------------------------------------------------------------#
# MANDATAIRES - TROISIEME SCENARIO                                             #
#------------------------------------------------------------------------------#
inputs  <- c("NbASCMoy","ExpMoyASC")
outputs <- paste0("Y", 1:8)
z_var <- c("AgeMoy","HeuresDebordement","HeuresSoir","HeuresWE",
           "NbJoursFeries","NbJourImma","PropImm","PropEnt","C0","C1","C2","C3")

df.3.MD.CLEAN <- df.3.MD %>% 
  filter(!if_any(all_of(c(inputs, outputs,z_var)), is.na)) %>%
  select(Mois, CD_POINT_SER, everything())%>% 
  mutate(AgeMoy=AgeMoy/100)

eff.3.MD <- dea_crs_vrs(df.3.MD.CLEAN, inputs, outputs, ORIENTATION = "in") %>%
  mutate(
    CD_POINT_SER = df.3.MD.CLEAN$CD_POINT_SER,
    Mois = df.3.MD.CLEAN$Mois
  ) %>% 
  left_join(df.3.MD.CLEAN, by = c("Mois","CD_POINT_SER"))

# L'estimation eff.3.MD.Z prend plusieurs minutes
eff.3.MD.Z <- dea_crs_vrs_Z(df.3.MD.CLEAN, inputs, outputs, z_var,ORIENTATION = "in") %>% 
  mutate(Mois=df.3.MD.CLEAN$Mois) %>% 
  left_join(df.3.MD.CLEAN, by = c("Mois","CD_POINT_SER"))

df <- eff.3.MD.Z %>%
  group_by(CD_POINT_SER) %>% 
  summarise(eff_brut=mean(eff_vrs),
            eff_net=mean(eff_vrs_Z),
            Nom=Nom[1]
  ) %>% 
  ungroup() %>% 
  mutate(
    rk_vrs1 = dense_rank(desc(eff_brut)),
    rk_vrs2 = dense_rank(desc(eff_net)),
    diff_rk = rk_vrs1 - rk_vrs2
  ) %>%
  select(Nom,CD_POINT_SER,eff_brut,eff_net,rk_vrs1,rk_vrs2,diff_rk) %>% 
  ungroup()

cor(df$rk_vrs1, df$rk_vrs2, method = "spearman", use = "complete.obs")
cor(df$rk_vrs1, df$rk_vrs2, method = "kendall",  use = "complete.obs")

fit_tobit <- tobit(
  eff_vrs ~  AgeMoy+HeuresDebordement+HeuresSoir+HeuresWE+
    +NbJoursFeries+NbJourImma+PropImm+PropEnt+C0+C1+C2+C3,
  left  = 0,
  right = 1,
  data = eff.3.MD.Z
)
summary(fit_tobit)

reg.3.MD <- attr(eff.3.MD.Z, "rdea_regression")

est <- reg.3.MD$beta_hat_hat
ci  <- reg.3.MD$beta_ci

se <- (ci[, 2] - ci[, 1]) / (2 * 1.96)
tval <- est / se
pval <- 2 * (1 - pnorm(abs(tval)))

coef_table <- data.frame(
  variable   = names(est),
  estimate   = as.numeric(est),
  std_error  = as.numeric(se),
  t_value    = as.numeric(tval),
  p_value    = as.numeric(pval)
  #ci_low     = ci[, 1],
  #ci_high    = ci[, 2]
)

coef_table.3.MD <- coef_table %>%
  mutate(
    stars = case_when(
      p_value < 0.01 ~ "***",
      p_value < 0.05 ~ "**",
      p_value < 0.10 ~ "*",
      TRUE ~ ""
    )
  )
coef_table.3.MD
#------------------------------------------------------------------------------#
# MD + CS - TROISIEME SCENARIO                                                 #
#------------------------------------------------------------------------------#
inputs  <- c("NbASCMoy","ExpMoyASC")
outputs <- paste0("Y", 1:8)
z_var <- c("AgeMoy","HeuresDebordement","PropImm","PropEnt","C0","C1","C2","C3")

df.3.CS.MD.CLEAN <- df.3.CS.MD %>% 
  filter(!if_any(all_of(c(inputs, outputs, z_var)), is.na)) %>%
  select(Mois, CD_POINT_SER, everything())

eff.3.CS.MD <- dea_crs_vrs(df.3.CS.MD.CLEAN, inputs, outputs, ORIENTATION = "in") %>%
  mutate(
    CD_POINT_SER = df.3.CS.MD.CLEAN$CD_POINT_SER,
    Mois = df.3.CS.MD.CLEAN$Mois
  ) %>% 
  left_join(df.3.CS.MD.CLEAN, by = c("Mois","CD_POINT_SER"))

# L'estimation eff.3.CS.MD.Z prend plusieurs minutes
eff.3.CS.MD.Z <- dea_crs_vrs_Z(df.3.CS.MD.CLEAN, inputs, outputs, z_var,ORIENTATION = "in") %>% 
  mutate(Mois=df.3.CS.MD.CLEAN$Mois) %>% 
  left_join(df.3.CS.MD.CLEAN, by = c("Mois","CD_POINT_SER"))

df <- eff.3.CS.MD.Z %>%
  group_by(CD_POINT_SER) %>% 
  summarise(eff_brut=mean(eff_vrs),
            eff_net=mean(eff_vrs_Z),
            Nom=Nom[1]
            ) %>% 
  ungroup() %>% 
  mutate(
    rk_vrs1 = dense_rank(desc(eff_brut)),
    rk_vrs2 = dense_rank(desc(eff_net)),
    diff_rk = rk_vrs1 - rk_vrs2
  ) %>%
  select(Nom,CD_POINT_SER,eff_brut,eff_net,rk_vrs1,rk_vrs2,diff_rk) %>% 
  ungroup()

cor(df$rk_vrs1, df$rk_vrs2, method = "spearman", use = "complete.obs")
cor(df$rk_vrs1, df$rk_vrs2, method = "kendall",  use = "complete.obs")

rank_firms <- eff.3.CS.MD %>%
  group_by(Annee,CD_POINT_SER) %>%
  summarise(mean_eff = mean(eff_vrs, na.rm = TRUE), .groups = "drop") %>%
  arrange(desc(mean_eff)) %>% 
  ungroup() %>% 
  left_join(df.3.CS.MD.CLEAN,by=c("Annee","CD_POINT_SER")) %>% 
  group_by(CD_POINT_SER) %>% 
  slice(1) %>% 
  select(-Annee,-Mois,-n_mois) %>% 
  arrange(desc(mean_eff))

fit_tobit <- tobit(
  eff_vrs ~  AgeMoy+HeuresDebordement+HeuresSoir+HeuresWE+
    NbJoursFeries+NbJourImma+PropImm+PropEnt+C0+C1+C2+C3,
  left  = 0,
  right = 1,
  data = eff.3.CS.MD.Z
)
summary(fit_tobit)

reg.3.CS.MD <- attr(eff.3.CS.MD.Z, "rdea_regression")

est <- reg.3.CS.MD$beta_hat_hat
ci  <- reg.3.CS.MD$beta_ci

se <- (ci[, 2] - ci[, 1]) / (2 * 1.96)
tval <- est / se
pval <- 2 * (1 - pnorm(abs(tval)))

coef_table <- data.frame(
  variable   = names(est),
  estimate   = as.numeric(est),
  std_error  = as.numeric(se),
  t_value    = as.numeric(tval),
  p_value    = as.numeric(pval)
  #ci_low     = ci[, 1],
  #ci_high    = ci[, 2]
)

coef_table.3.CS.MD <- coef_table %>%
  mutate(
    stars = case_when(
      p_value < 0.01 ~ "***",
      p_value < 0.05 ~ "**",
      p_value < 0.10 ~ "*",
      TRUE ~ ""
    )
  )
coef_table.3.CS.MD
#------------------------------------------------------------------------------#
# SAUVEGARDE DES RÉSULTATS DES RÉGRESSIONS DANS UN FICHIER EXCEL               #
#------------------------------------------------------------------------------#
reg <- createWorkbook()
addWorksheet(reg, "3.CS")
addWorksheet(reg, "3.MD")
addWorksheet(reg, "3.CS.MD")

writeData(reg,"3.CS",coef_table.3.CS)
writeData(reg,"3.MD",coef_table.3.MD)
writeData(reg,"3.CS.MD",coef_table.3.CS.MD)

saveWorkbook(reg, paste0(Resultats_path,"Regressions.3.xlsx"), overwrite = TRUE)
#------------------------------------------------------------------------------#
# SAUVEGARDE DES SCORES D'EFFICACITÉ DANS UN FICHIER EXCEL                     #
#------------------------------------------------------------------------------#
wb <- createWorkbook()
addWorksheet(wb, "3.CS")
addWorksheet(wb, "3.MD")
addWorksheet(wb, "3.CS.MD")

df.Taille <- df.Principale %>% 
  group_by(CD_POINT_SER) %>% 
  filter(Annee==2025) %>% 
  summarise(Taille=sum(NbVisites))

Tab.3.CS <- eff.3.CS.Z %>% 
  arrange(desc(eff_vrs)) %>% 
  group_by(CD_POINT_SER) %>% 
  summarise(
    Nom = first(Nom),
    Canal =first(Canal),
    across(where(is.numeric), \(x) mean(x, na.rm = TRUE)),
    .groups = "drop"
  ) %>% 
  select(Nom,CD_POINT_SER, eff_vrs, eff_crs,scale_eff,all_of(z_var),-Annee,-Mois) %>% 
  arrange(desc(eff_vrs)) %>% 
  left_join(df.Taille, by="CD_POINT_SER")

Tab.3.MD <- eff.3.MD %>% 
  arrange(desc(eff_vrs)) %>% 
  group_by(CD_POINT_SER) %>% 
  summarise(
    Nom = first(Nom),
    Canal =first(Canal),
    across(where(is.numeric), \(x) mean(x, na.rm = TRUE)),
    .groups = "drop"
  ) %>% 
  select(Nom,CD_POINT_SER, eff_vrs, eff_crs,scale_eff,all_of(z_var),-Annee,-Mois) %>% 
  arrange(desc(eff_vrs)) %>% 
  left_join(df.Taille, by="CD_POINT_SER")

Tab.3.CS.MD <- eff.3.CS.MD %>% 
  arrange(desc(eff_vrs)) %>% 
  group_by(CD_POINT_SER) %>% 
  summarise(
    Nom = first(Nom),
    Canal =first(Canal),
    across(where(is.numeric), \(x) mean(x, na.rm = TRUE)),
    .groups = "drop"
  ) %>% 
  select(Nom,Canal,CD_POINT_SER, eff_vrs, eff_crs,scale_eff,all_of(z_var),-Annee,-Mois) %>% 
  arrange(desc(eff_vrs)) %>% 
  left_join(df.Taille, by="CD_POINT_SER")

writeData(wb,"3.CS",Tab.3.CS)
writeData(wb,"3.MD",Tab.3.MD)
writeData(wb,"3.CS.MD",Tab.3.CS.MD)

saveWorkbook(wb, paste0(Resultats_path,"EfficacitéMensuelle.xlsx"), 
             overwrite = TRUE)
#------------------------------------------------------------------------------#
# FIGURES - LIENS ENTRE TAILLE ET EFFICACITÉ                                   #                                                                     #
#------------------------------------------------------------------------------#
g.MD <- Tab.3.MD %>%
  ggplot(aes(x = Taille, y = eff_vrs)) +
  geom_point(alpha = 0.4, size = 1, color = "grey40") +
  geom_smooth(method = "gam", formula = y ~ s(x), se = TRUE, color = "steelblue") +
  scale_x_continuous(
    labels = scales::label_number(big.mark = " "),
    breaks = scales::pretty_breaks(n = 15)
  ) +
  theme_minimal() +
  theme(
    axis.text.x = element_text(angle = 90, vjust = 0.5, hjust = 1)
  ) +
  labs(
    title = "",
    x = "Nombre d'opérations en 2025",
    y = "Efficacité (VRS)"
  )
g.MD
ggsave(
  filename = paste0(Resultats_path,"g_Taille_Efficacité_MD.pdf"),
  plot = g.MD,
  device = "pdf",
  width = 8,
  height = 6,
  units = "in"
)

g.CS <- Tab.3.CS %>%
  ggplot(aes(x = Taille, y = eff_vrs)) +
  geom_point(alpha = 0.4, size = 1, color = "grey40") +
  geom_smooth(method = "gam", formula = y ~ s(x), se = TRUE, color = "steelblue") +
  scale_x_continuous(
    labels = scales::label_number(big.mark = " "),
    breaks = scales::pretty_breaks(n = 15)
  ) +
  theme_minimal() +
  theme(
    axis.text.x = element_text(angle = 90, vjust = 0.5, hjust = 1)
  ) +
  labs(
    title = "",
    x = "Nombre d'opérations en 2025",
    y = "Efficacité (VRS)"
  )
g.CS
ggsave(
  filename = paste0(Resultats_path,"g_Taille_Efficacité_CS.pdf"),
  plot = g.CS,
  device = "pdf",
  width = 8,
  height = 6,
  units = "in"
)
#------------------------------------------------------------------------------#
# FIGURES - HEATH MAP, MANDATAIRES.                                            #                                                                     #
#------------------------------------------------------------------------------#
g.MD.HM <- Tab.3.MD %>%
  arrange(eff_vrs) %>%
  mutate(Nom = factor(Nom, levels = Nom)) %>%
  rename(Efficacité=eff_vrs) %>% 
  ggplot(aes(x = Nom, y = Efficacité)) +
  geom_col(aes(fill = Efficacité)) +
  scale_color_manual(values = c("white", "black"), guide = "none")+
  scale_fill_viridis_c()+
  coord_flip() +
  theme_minimal() +
  geom_text(aes(label = round(Efficacité, 2)),
            hjust = -0.1,
            size = 1.75)+
  theme(
    axis.text.y = element_text(size = 7)
  )+
  labs(
    title = "",
    x = "",
    y = "Efficacité"
  )
g.MD.HM
ggsave(
  filename = paste0(Resultats_path,"g_Efficacité.MD.HM.pdf"),
  plot = g.MD.HM,
  device = "pdf",
  width = 6,
  height = 8,
  units = "in"
)
#------------------------------------------------------------------------------#
# FIGURES - HEATH MAP, CENTRES DE SERVICES                                     #                                                                     #
#------------------------------------------------------------------------------#
g.CS.HM <- Tab.3.CS %>%
  arrange(eff_vrs) %>%
  mutate(Nom = factor(Nom, levels = Nom)) %>%
  rename(Efficacité=eff_vrs) %>% 
  ggplot(aes(x = Nom, y = Efficacité)) +
  geom_col(aes(fill = Efficacité)) +
  scale_color_manual(values = c("white", "black"), guide = "none")+
  scale_fill_viridis_c()+
  coord_flip() +
  theme_minimal() +
  geom_text(aes(label = round(Efficacité, 2)),
            hjust = -0.1,
            size = 1.75)+
  theme(
    axis.text.y = element_text(size = 7)
  )+
  labs(
    title = "",
    x = "",
    y = "Efficacité"
  )
g.CS.HM
ggsave(
  filename = paste0(Resultats_path,"g_Efficacité.CS.HM.pdf"),
  plot = g.CS.HM,
  device = "pdf",
  width = 6,
  height = 8,
  units = "in"
)
#------------------------------------------------------------------------------#
