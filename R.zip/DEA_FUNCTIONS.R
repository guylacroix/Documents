dea_crs_vrs <- function(dat, inputs, outputs, ORIENTATION = "in") {
  
  dat2 <- dat |>
    dplyr::select(CD_POINT_SER, dplyr::all_of(inputs), dplyr::all_of(outputs)) |>
    dplyr::mutate(dplyr::across(dplyr::all_of(c(inputs, outputs)), as.numeric)) |>
    dplyr::filter(dplyr::if_all(dplyr::all_of(c(inputs, outputs)), is.finite))
  
  if (nrow(dat2) < 2) return(tibble::tibble())
  
  X <- as.matrix(dat2[, inputs, drop = FALSE])
  Y <- as.matrix(dat2[, outputs, drop = FALSE])
  
  model <- if (tolower(ORIENTATION) == "in") "input" else "output"
  
  crs <- rDEA::dea(XREF = X, YREF = Y, X = X, Y = Y, model = model, RTS = "constant")
  vrs <- rDEA::dea(XREF = X, YREF = Y, X = X, Y = Y, model = model, RTS = "variable")
  
  eff_crs <- as.numeric(crs$thetaOpt)  # (0,1)
  eff_vrs <- as.numeric(vrs$thetaOpt)
  
  tibble::tibble(
    CD_POINT_SER = dat2$CD_POINT_SER,
    eff_crs = eff_crs,
    eff_vrs = eff_vrs,
    scale_eff = eff_crs / eff_vrs
  )
}

dea_crs_vrs_Z <- function(data, inputs, outputs, z_var = NULL,
                                   ORIENTATION = "in",
                                   tol = 1e-6,
                                   rdea_RTS = "vrs",     # "vrs" ou "crs" (pour la partie conditionnelle)
                                   rdea_model = "input"  # "input" ou "output"
) {
  
  stopifnot(ORIENTATION %in% c("in", "out"))
  stopifnot(rdea_model %in% c("input", "output"))
  stopifnot(rdea_RTS %in% c("vrs", "crs"))
  
  # --- 1) Nettoyage / mise en forme (X,Y + éventuellement Z)
  cols_keep <- c("CD_POINT_SER", inputs, outputs, z_var)
  cols_keep <- unique(cols_keep)
  
  data2 <- data %>%
    dplyr::select(dplyr::all_of(cols_keep)) %>%
    dplyr::mutate(
      dplyr::across(dplyr::all_of(c(inputs, outputs, z_var)), as.numeric)
    ) %>%
    dplyr::filter(
      dplyr::if_all(dplyr::all_of(c(inputs, outputs)), is.finite),
      if (is.null(z_var) || length(z_var) == 0) TRUE else
        dplyr::if_all(dplyr::all_of(z_var), is.finite)
    )
  
  if (nrow(data2) < 2) return(tibble::tibble())
  
  X <- as.matrix(data2[, inputs, drop = FALSE])
  Y <- as.matrix(data2[, outputs, drop = FALSE])
  
  # --- 2) DEA "standard" (Benchmarking): CRS, VRS, NDRS, NIRS
  dea_crs  <- Benchmarking::dea(X, Y, RTS = "crs", ORIENTATION = ORIENTATION)
  dea_vrs  <- Benchmarking::dea(X, Y, RTS = "vrs", ORIENTATION = ORIENTATION)
  dea_ndrs <- Benchmarking::dea(X, Y, RTS = "irs", ORIENTATION = ORIENTATION) # non-decreasing
  dea_nirs <- Benchmarking::dea(X, Y, RTS = "drs", ORIENTATION = ORIENTATION) # non-increasing
  
  eff_crs  <- as.numeric(dea_crs$eff)
  eff_vrs  <- as.numeric(dea_vrs$eff)
  eff_ndrs <- as.numeric(dea_ndrs$eff)
  eff_nirs <- as.numeric(dea_nirs$eff)
  
  # --- 3) Scale efficiency + RTS class
  scale_eff <- eff_crs / eff_vrs
  
  rts_class <- dplyr::case_when(
    abs(eff_crs - eff_vrs)  <= tol ~ "CRS",
    abs(eff_nirs - eff_vrs) <= tol ~ "DRS",
    abs(eff_ndrs - eff_vrs) <= tol ~ "IRS",
    TRUE ~ "Ambigu (tolérance)"
  )
  
  out <- tibble::tibble(
    CD_POINT_SER = data2$CD_POINT_SER,
    eff_crs      = eff_crs,
    eff_vrs      = eff_vrs,
    scale_eff    = scale_eff,
    eff_ndrs     = eff_ndrs,
    eff_nirs     = eff_nirs,
    rts_class    = rts_class
  )
  
  # --- 4) Bloc optionnel : DEA conditionnelle à Z (rDEA)
  # Note: Benchmarking n'a pas d'argument Z; on ajoute donc des colonnes "…_Z".
  if (!is.null(z_var) && length(z_var) > 0) {
    
    #Z <- as.matrix(data2[, z_var, drop = FALSE])
    Z <- scale(as.matrix(data2[, z_var, drop=FALSE]))
    
    res_env <- rDEA::dea.env.robust(
      X = X, Y = Y, Z = Z,
      RTS = rdea_RTS,
      model = rdea_model
    )
    
    # Extraction (votre version renvoie delta_*)
    effZ <- dplyr::coalesce(
      res_env$delta_hat_hat,
      res_env$delta_hat
    )
    
    if (is.null(effZ)) {
      stop("dea.env.robust() n'a renvoyé aucun champ delta_* exploitable.")
    }
    
    effZ <- as.numeric(effZ)
    if (length(effZ) != nrow(X)) {
      stop("Longueur de effZ (delta_*) différente du nombre d'observations.")
    }
    if (rdea_model == "input") {
      effZ <- 1 / effZ
    }
    if (rdea_RTS == "vrs") {
      out <- dplyr::mutate(out, eff_vrs_Z = effZ)
    } else {
      out <- dplyr::mutate(out, eff_crs_Z = effZ)
    }
  }
  if (!is.null(z_var) && length(z_var) > 0) {
    attr(out, "rdea_regression") <- res_env
  }
  return(out) 
}

